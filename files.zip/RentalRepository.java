package com.programmers.team6.comic_rental.repository;

import com.programmers.team6.comic_rental.entity.Rental;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.programmers.team6.global.jdbc.DBConnectionUtil.close;
import static com.programmers.team6.global.jdbc.DBConnectionUtil.getConnection;

public class RentalRepository {

    // ✅ 대여 저장 (INSERT)
    public Rental save(Rental rental) throws SQLException {
        String sql = "INSERT INTO rental(comic_id, member_id, rent_date, return_date, created_date, updated_date) " +
                     "VALUES(?, ?, ?, ?, ?, ?)";

        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            con = getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, rental.getComicId());
            pstmt.setLong(2, rental.getMemberId());
            pstmt.setTimestamp(3, Timestamp.valueOf(rental.getRentDate()));
            pstmt.setNull(4, Types.TIMESTAMP);  // 반납일 처음엔 null
            pstmt.setTimestamp(5, Timestamp.valueOf(rental.getCreatedDate()));
            pstmt.setTimestamp(6, Timestamp.valueOf(rental.getUpdatedDate()));
            pstmt.executeUpdate();
            return rental;
        } catch (SQLException e) {
            System.err.println("[Error] 대여 저장 실패: " + e.getMessage());
            throw e;
        } finally {
            close(con, pstmt, null);
        }
    }

    // ✅ 반납 처리 (UPDATE)
    public void returnRental(Long rentalId, LocalDateTime returnDate) throws SQLException {
        String sql = "UPDATE rental SET return_date = ?, updated_date = ? WHERE rental_id = ?";

        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            con = getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setTimestamp(1, Timestamp.valueOf(returnDate));
            pstmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            pstmt.setLong(3, rentalId);

            int rows = pstmt.executeUpdate();
            if (rows == 0) {
                throw new SQLException("해당 대여 ID가 존재하지 않습니다: " + rentalId);
            }
        } catch (SQLException e) {
            System.err.println("[Error] 반납 처리 실패: " + e.getMessage());
            throw e;
        } finally {
            close(con, pstmt, null);
        }
    }

    // ✅ 전체 대여 목록 조회 (SELECT)
    public List<Rental> findAll() throws SQLException {
        String sql = "SELECT rental_id, comic_id, member_id, rent_date, return_date, " +
                     "created_date, updated_date FROM rental ORDER BY rental_id";

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Rental> list = new ArrayList<>();

        try {
            con = getConnection();
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Timestamp returnTs = rs.getTimestamp("return_date");
                Rental rental = new Rental(
                        rs.getLong("rental_id"),
                        rs.getLong("comic_id"),
                        rs.getLong("member_id"),
                        rs.getTimestamp("rent_date").toLocalDateTime(),
                        returnTs != null ? returnTs.toLocalDateTime() : null,
                        rs.getTimestamp("created_date").toLocalDateTime(),
                        rs.getTimestamp("updated_date").toLocalDateTime()
                );
                list.add(rental);
            }
            return list;
        } catch (SQLException e) {
            System.err.println("[Error] 대여 목록 조회 실패: " + e.getMessage());
            throw e;
        } finally {
            close(con, pstmt, rs);
        }
    }

    // ✅ 단건 조회 (반납 시 체크용)
    public Rental findById(Long rentalId) throws SQLException {
        String sql = "SELECT rental_id, comic_id, member_id, rent_date, return_date, " +
                     "created_date, updated_date FROM rental WHERE rental_id = ?";

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, rentalId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                Timestamp returnTs = rs.getTimestamp("return_date");
                return new Rental(
                        rs.getLong("rental_id"),
                        rs.getLong("comic_id"),
                        rs.getLong("member_id"),
                        rs.getTimestamp("rent_date").toLocalDateTime(),
                        returnTs != null ? returnTs.toLocalDateTime() : null,
                        rs.getTimestamp("created_date").toLocalDateTime(),
                        rs.getTimestamp("updated_date").toLocalDateTime()
                );
            } else {
                throw new SQLException("해당 대여 ID가 없습니다: " + rentalId);
            }
        } catch (SQLException e) {
            System.err.println("[Error] 단건 조회 실패: " + e.getMessage());
            throw e;
        } finally {
            close(con, pstmt, rs);
        }
    }

    // ✅ 만화책 대여중 여부 확인
    public boolean isRented(Long comicId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM rental WHERE comic_id = ? AND return_date IS NULL";

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, comicId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (SQLException e) {
            System.err.println("[Error] 대여 여부 확인 실패: " + e.getMessage());
            throw e;
        } finally {
            close(con, pstmt, rs);
        }
    }
}
