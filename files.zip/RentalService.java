package com.programmers.team6.comic_rental.service;

import com.programmers.team6.comic_rental.entity.Rental;
import com.programmers.team6.comic_rental.repository.RentalRepository;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

public class RentalService {

    private final RentalRepository rentalRepository = new RentalRepository();

    // ✅ 대여 처리
    public void rentBook(Long memberId, Long comicId) throws SQLException {
        // 이미 대여중인지 체크
        if (rentalRepository.isRented(comicId)) {
            throw new IllegalStateException("이미 대여중인 만화책입니다. (comicId=" + comicId + ")");
        }

        LocalDateTime now = LocalDateTime.now();
        Rental rental = new Rental(comicId, memberId, now, now, now);
        rentalRepository.save(rental);

        System.out.println("[Service] 대여 완료 - 회원: " + memberId + ", 만화책: " + comicId);
    }

    // ✅ 반납 처리
    public void returnBook(Long rentalId) throws SQLException {
        // 대여 ID 존재 + 이미 반납됐는지 체크
        Rental rental = rentalRepository.findById(rentalId);

        if (rental.getReturnDate() != null) {
            throw new IllegalStateException("이미 반납된 대여입니다. (rentalId=" + rentalId + ")");
        }

        rentalRepository.returnRental(rentalId, LocalDateTime.now());
        System.out.println("[Service] 반납 완료 - 대여ID: " + rentalId);
    }

    // ✅ 전체 대여 목록 조회
    public List<Rental> getRentalList() throws SQLException {
        return rentalRepository.findAll();
    }
}
