package com.programmers.team6.comic_rental.controller;

import com.programmers.team6.comic_rental.entity.Rental;
import com.programmers.team6.comic_rental.service.RentalService;

import java.util.List;
import java.util.Scanner;

public class RentalController {

    private final RentalService rentalService = new RentalService();
    private final Scanner scanner = new Scanner(System.in);

    // ✅ 대여 처리
    public void processRental() {
        System.out.println("\n======= 만화책 대여 =======");
        try {
            System.out.print("회원 ID: ");
            Long memberId = Long.parseLong(scanner.nextLine().trim());

            System.out.print("만화책 ID: ");
            Long comicId = Long.parseLong(scanner.nextLine().trim());

            rentalService.rentBook(memberId, comicId);
            System.out.println(">>> 대여 완료!");

        } catch (NumberFormatException e) {
            System.out.println("[오류] ID는 숫자만 입력하세요.");
        } catch (IllegalStateException e) {
            System.out.println("[오류] " + e.getMessage());
        } catch (Exception e) {
            System.out.println("[오류] " + e.getMessage());
        }
    }

    // ✅ 반납 처리
    public void processReturn() {
        System.out.println("\n======= 만화책 반납 =======");
        try {
            System.out.print("반납할 대여 ID: ");
            Long rentalId = Long.parseLong(scanner.nextLine().trim());

            rentalService.returnBook(rentalId);
            System.out.println(">>> 반납 완료! (대여ID=" + rentalId + ")");

        } catch (NumberFormatException e) {
            System.out.println("[오류] ID는 숫자만 입력하세요.");
        } catch (IllegalStateException e) {
            System.out.println("[오류] " + e.getMessage());
        } catch (Exception e) {
            System.out.println("[오류] " + e.getMessage());
        }
    }

    // ✅ 대여 목록 출력
    public void showRentalList() {
        System.out.println("\n======= 대여 목록 =======");
        try {
            List<Rental> list = rentalService.getRentalList();

            if (list.isEmpty()) {
                System.out.println("대여 내역이 없습니다.");
                return;
            }

            System.out.printf("%-10s %-10s %-10s %-22s %-22s%n",
                    "대여ID", "만화ID", "회원ID", "대여일", "반납일");
            System.out.println("-".repeat(75));

            for (Rental r : list) {
                System.out.printf("%-10d %-10d %-10d %-22s %-22s%n",
                        r.getRentalId(),
                        r.getComicId(),
                        r.getMemberId(),
                        r.getRentDate(),
                        r.getReturnDate() != null ? r.getReturnDate() : "미반납"
                );
            }
        } catch (Exception e) {
            System.out.println("[오류] " + e.getMessage());
        }
    }
}
